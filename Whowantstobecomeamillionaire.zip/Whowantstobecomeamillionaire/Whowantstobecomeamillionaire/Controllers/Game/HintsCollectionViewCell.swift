//
//  HintsCollectionViewCell.swift
//  Whowantstobecomeamillionaire
//
//  Created by Aleksei Niskarav on 17/02/2020.
//  Copyright © 2020 Aleksei Niskarav. All rights reserved.
//

import UIKit

class HintsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var fiftyButton: UIButton!
    @IBOutlet weak var changeButton: UIButton!
    @IBOutlet weak var insuranceButton: UIButton!
}
