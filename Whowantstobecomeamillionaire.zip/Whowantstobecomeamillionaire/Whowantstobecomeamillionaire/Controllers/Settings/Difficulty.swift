//
//  Difficulty.swift
//  Whowantstobecomeamillionaire
//
//  Created by Aleksei Niskarav on 25/02/2020.
//  Copyright © 2020 Aleksei Niskarav. All rights reserved.
//

import Foundation

enum Difficulty {
    case easy, hard
}
